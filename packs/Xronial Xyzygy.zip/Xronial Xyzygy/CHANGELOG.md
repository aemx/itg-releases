# Changelog
_All notable changes to Xronial Xyzygy will be documented in this file._

## v1.0 (2020-03-21)
- Initial release