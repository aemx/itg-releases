# Changelog
_All notable changes to Xronial Xyzygy will be documented in this file._

## v1.0.1 (2023-02-16)
- Fix spelling error in Abyss of Frobenioid

## v1.0 (2020-03-21)
- Initial release