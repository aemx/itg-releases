# Changelog
_All notable changes to Omega Dimension will be documented in this file._

## v1.1 (2022-09-04)
- Reduce size of guide/info.pdf

## v1.0 (2019-05-12)
- Initial release